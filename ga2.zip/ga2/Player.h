#include <string>
using namespace std;

struct Player {
	int age;
	int number;
	int minutes;
	string status;

	Player *prev;
	Player *next;

	Player *game_prev;
	Player *game_next;
};