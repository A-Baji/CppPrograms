#include "Team.h"
#include <string>
#include <math.h>
using namespace std;

class Game {
    private:
        Court* court;
        Bench* bench;
    public:
        Game();
        Game(Court*, Bench*);
        void quarter(int minutes);
};

Game::Game() {
    court = 0;
    bench =0;
}

Game::Game(Court* _court, Bench* _bench) {
    court = _court;
    bench = _bench;
}

void Game::quarter(int minutes) {
    while (minutes > 0) {
		//cout << court->getSize();
        Player* oldestPlayer = court->findOldest();
        int time = floor(oldestPlayer->age*.1) - oldestPlayer->minutes;

        // End of Quarter, but no swaps needed
        if (time>minutes) {
            time = minutes;
            court->addMinutes(time);
            minutes -= time;
        }

        // Time left with swaps needed
        else {
            court->addMinutes(time);
            minutes -= time;

            // PULL PLAYERS NEED TO BE FIXED STACK

            Player* toBeBenched = court->pullPlayer(oldestPlayer);
            Player* toBePlayed = bench->pullPlayer();

            court->addPlayer(toBePlayed);
            bench->addPlayer(toBeBenched);
        }
    }
}