#include "Player.h"
#include <string>
#include <fstream>
#include <iostream>
using namespace std;

// ---------- //
// -- TEAM -- //
// ---------- //
class Team {
	private:
		Player* head;
		Player* tail;
		int size;
	public:
		Team();
        void printPlayer(Player* player);
        void print();
        void getPlayersFromFile(string filename);
		void addPlayer(int age);
        Player* getRandomPlayer();
        Player* getUnassignedPlayer();
};

Team::Team() {
    head = 0;
    tail = 0;
    size = 0;
}

void Team::printPlayer(Player* player) {
    cout << player->age << "\t";
    cout << player->number << "\t";
    cout << player->minutes << "\t";
    cout << player->status << endl;
}

void Team::print() {
    cout << "\tPLAYERS ON THE TEAM" << endl;
    cout << "Age" << "\t";
    cout << "Number" << "\t";
    cout << "Minutes" << "\t";
    cout << "Status" << endl;
    Player* temp = head;
    for (int i=0;i<size;i++) {
        printPlayer(temp);
        temp = temp->next;
    }
}

void Team::getPlayersFromFile(string filename) {
    ifstream ifs;
	ifs.open(filename);
	if (ifs.is_open()) {
        // Auto assigns number only need age
		while (!ifs.eof()) {
			int age;
			ifs >> age;
            addPlayer(age);
		}
	}
	ifs.close();
}

void Team::addPlayer(int age) {
    size += 1;

    // Add to Team
    Player* temp = new Player;
    temp->age = age;
    temp->number = size;
    temp->minutes = 0;
    temp->status = "";

    // Empty Team
    if (head == 0) {
        head = temp;
        tail = temp;
        temp = 0;
    }
    else {
        tail->next = temp;
        tail = temp;
    }
}

Player* Team::getRandomPlayer() {
    int random = rand() % size;
    int pushes = 0;
    Player* out = head;

    // Loops through list random amount of times
    for (int i=0; i<random; i++) {
        out = out->next;
    }

    // If lands on player on court goes to next one
    while (out->status == "c") {
        if(out->next == 0) {
            out = head;
            pushes++;
        } else {
            out = out->next;
            pushes++;

            // No more non court players, return 0
            if (pushes > size) {
                return 0;
            }
        }
    }
    return out;
}

Player* Team::getUnassignedPlayer() {
    Player* out = head;
    for (int i=0; i<size; i++) {
        if(out->status == "") {
            return out;
        }
        out = out->next;
    }
    return 0;
}

// ----------- //
// -- COURT -- //
// ----------- //

class Court {
    private:
		Player* head;
        Player* tail;
        int size;
    public:
        Court();
        int getSize();
        void printPlayer(Player* player);
        void print();
        void addPlayer(Player* player);
        void addMinutes(int m);
        Player* pullPlayer(Player* player);
        Player* findOldest();
};

Court::Court() {
    tail = 0;
    head = 0;
    size = 5;
}

int Court::getSize() {
    return size;
}

void Court::printPlayer(Player* player) {
    cout << player->age << "\t";
    cout << player->number << "\t";
    cout << player->minutes << "\t";
    cout << player->status << endl;
}

void Court::print() {
    cout << "\tPLAYERS ON COURT" << endl;
    cout << "Age" << "\t";
    cout << "Number" << "\t";
    cout << "Minutes" << "\t";
    cout << "Status" << endl;
    Player* temp = head;
    for (int i=0; i<size; i++) {
        printPlayer(temp);
        temp = temp->game_next;
    }
}

void Court::addPlayer(Player* player) {
	if (size != 5)
		size += 1;
    player->status = "c";

    if (tail == 0) {
        player->game_prev = 0;
        player->game_next = 0;
        tail = player;
        head = player;
    } else {
        player->game_prev = head;
        player->game_next = tail;
        tail->game_prev = player;
        head->game_next = player;
        head = player;
    }
}

void Court::addMinutes(int m) {
    Player* temp = head;
    for (int i=0; i<size; i++) {
        temp->minutes += m;
		if (temp->game_next != NULL)
			temp = temp->game_next;
    }
}

Player* Court::pullPlayer(Player* player) {
    Player* temp = tail;
    for(int i=0;i<size;i++) {
        if(temp->number == player->number) {
            if (temp->number == head->number) {
                head = temp->game_prev;
            }
            else if (temp->number == tail->number) {
                tail = temp->game_next;
            }
			if (temp->game_prev != NULL)
				temp->game_prev->game_next = temp->game_next;
			if (temp->game_next != NULL)
				temp->game_next->game_prev = temp->game_prev;

            temp->game_prev = 0;
            temp->game_next = 0;

			size-=1;
			//cout << endl << "SIZE: " << size << endl;
            return temp;
        }
		if (temp->game_next != NULL)
			temp = temp->game_next;
    }
    return 0;
}

Player* Court::findOldest() {
    Player* temp = head;
    Player* oldest = temp;
    for(int i=0;i<size;i++) {
        if(temp->age > oldest->age) {
            oldest = temp;
        }
		if (temp->game_next != NULL)
			temp = temp->game_next;
    }
    return oldest;
}

// ----------- //
// -- BENCH -- //
// ----------- //

class Bench {
    private:
        Player* left;
		Player* right;
        int side;
        int size;
    public:
        Bench();
        void printPlayer(Player* player);
        void print();
        void addPlayer(Player* player);
        Player* pullPlayer();
};

Bench::Bench() {
    left = 0;
    right = 0;
    side = 0;
    size = 7;
}

void Bench::printPlayer(Player* player) {
    cout << player->age << "\t";
    cout << player->number << "\t";
    cout << player->minutes << "\t";
    cout << player->status << endl;
}

void Bench::print() {
    cout << "\tPLAYERS ON BENCH" << endl;
    cout << "Age" << "\t";
    cout << "Number" << "\t";
    cout << "Minutes" << "\t";
    cout << "Status" << endl;
    Player* temp = left;
    for (int i=0; i<size; i++) {
        printPlayer(temp);
        temp = temp->game_next;
    }
}

void Bench::addPlayer(Player* player) {
	if (size != 7)
		size += 1;
    player->status = "b";

    if (left == 0) {
        player->game_prev = 0;
        player->game_next = 0;
        left = player;
        right = player;
    } 
    else if (side%2 == 0) {
        side++;
        player->game_prev = 0;
        player->game_next = left;
        left->game_prev = player;
        left = player;
    }
    else if (side%2 == 1) {
        side--;
        player->game_prev = right;
        player->game_next = 0;
        right->game_next = player;
        right = player;
    }
}

Player* Bench::pullPlayer() {
    Player* out = 0;
    if(side%2 == 0) {
        // Pull from left side
        side++;
        out = left->game_next;

        left->game_next = out->game_next;
        out->game_next->game_prev = left;
    }
    else if (side%2 == 1) {
        // Pull from right side
        side--;
        out = right->game_prev;

        right->game_prev = out->game_prev;
		if (out->game_prev != NULL)
			out->game_prev->game_next = right;
    }
    size -= 1;

    return out;
}

// ----------- //
// -- OTHER -- //
// ----------- //

void getPlayersOnCourt(int num, Team* team, Court* court) {
    for (int i=0;i<num; i++) {
        Player* random = team->getRandomPlayer();
        if (random != 0)
            court->addPlayer(team->getRandomPlayer());
        else
            break;
    }
}

void getPlayersOnBench(Team* team, Bench* bench) {
    Player* unassignedPlayer;
    int benchNum = 0;
    do {
        unassignedPlayer = team->getUnassignedPlayer();
        if (unassignedPlayer != 0) {
            benchNum++;
            if (benchNum%2 == 0)
                bench->addPlayer(unassignedPlayer);
            if (benchNum%2 == 1)
                bench->addPlayer(unassignedPlayer);
        } else {
            break;
        }
    } while (unassignedPlayer != 0);
}

void printInfo(Team* team, Court* court, Bench* bench) {
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" << endl;
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" << endl;
    team->print();
    cout << "--------------------------------------" << endl;
    court->print();
    cout << "--------------------------------------" << endl;
    bench->print();
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" << endl;
    cout << "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" << endl;
}