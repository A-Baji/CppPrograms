//#include "pch.h"
#include "ArgumentManager.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

class BTreeNode {
	int* keys;
	int minDegree;
	BTreeNode** childPtrs;
	int nKeys;
	bool leaf;
public:
	BTreeNode(int, bool);
	void insert(int);
	void split(int, BTreeNode*);
	void traverse();
	BTreeNode* search(int);
	friend class BTree;
};

BTreeNode::BTreeNode(int md, bool lf) {
	minDegree = md;
	leaf = lf;
	keys = new int[2 * minDegree - 1];
	childPtrs = new BTreeNode*[2 * minDegree];
	nKeys = 0;
}

void BTreeNode::insert(int k) {
	int i = nKeys - 1;
	if (leaf) {
		while (i >= 0 && keys[i] > k) {
			keys[i + 1] = keys[i];
			i--;
		}
		keys[i + 1] = k;
		nKeys = nKeys + 1;
	}
	else {
		while (i >= 0 && keys[i] > k)
			i--;
		if (childPtrs[i + 1]->nKeys == 2 * minDegree - 1) {
			split(i + 1, childPtrs[i + 1]);
			if (keys[i + 1] < k)
				i++;
		}
		childPtrs[i + 1]->insert(k);
	}
}

void BTreeNode::split(int i, BTreeNode* s) {
	BTreeNode* branch = new BTreeNode(s->minDegree, s->leaf);
	branch->nKeys = minDegree - 1;

	for (int j = 0; j < minDegree - 1; j++)
		branch->keys[j] = s->keys[j + minDegree];
	if (!s->leaf) {
		for (int j = 0; j < minDegree; j++)
			branch->childPtrs[j] = s->childPtrs[j + minDegree];
	}
	s->nKeys = minDegree - 1;
	for (int j = nKeys; j >= i + 1; j--)
		childPtrs[j + 1] = childPtrs[j];
	childPtrs[i + 1] = branch;
	for (int j = nKeys - 1; j >= i; j--)
		keys[j + 1] = keys[j];
	keys[i] = s->keys[minDegree - 1];
	nKeys += 1;
}

void BTreeNode::traverse() {
	int i;
	for (i = 0; i < nKeys; i++) {
		if (!leaf)
			childPtrs[i]->traverse();
		cout << keys[i] << " ";
	}
	if (!leaf)
		childPtrs[i]->traverse();
}

BTreeNode* BTreeNode::search(int k) {
	int i = 0;
	while (i < nKeys && k > keys[i])
		i++;
	if (keys[i] == k)
		return this;
	if (leaf)
		return NULL;
	return childPtrs[i]->search(k);
}

class BTree {
	BTreeNode* root;
	int minDegree;
public:
	BTree(int);
	void traverse();
	BTreeNode* search(int);
	void insert(int);
	void printLevel(int);
};

BTree::BTree(int md) {
	root = NULL;
	minDegree = md;
}

void BTree::traverse() {
	if (root != NULL)
		root->traverse();
}

BTreeNode* BTree::search(int k) {
	if (root == NULL)
		return NULL;
	else
		return root->search(k);
}

void BTree::insert(int k) {
	if (root == NULL) {
		root = new BTreeNode(minDegree, true);
		root->keys[0] = k;
		root->nKeys = 1;
	}
	else {
		if (root->nKeys == 2 * minDegree - 1) {
			BTreeNode* temp = new BTreeNode(minDegree, false);
			temp->childPtrs[0] = root;
			temp->split(0, root);

			int i = 0;
			if (temp->keys[0] < k)
				i++;
			temp->childPtrs[i]->insert(k);

			root = temp;
		}
		else
			root->insert(k);
	}
}

int printVector(vector<int> v) {
	for (const auto& i : v) {
		cout << endl << i << ' ';
	}
}

void findNodesAtLevelX(vector<int>& results, BTreeNode* root, const int& level, int curLevel) {
	if (!root)
		return;

	if (curLevel == level) {
		results.push_back(root->val);
		return;
	}

	findNodesAtLevelX(results, root->left, level, curLevel + 1);
	findNodesAtLevelX(results, root->right, level, curLevel + 1);
	return;

}

void printLevel(BTreeNode* rt, int lvl) {
	vector<int> vec;
	findNodesAtLevelX(vec, rt, lvl, 0); // start at level 0;
	printVector(vec);
	return;
}

template <typename T>
void printVector(T ourVector) {
	cout << " [";
	for (const auto& num : ourVector) {
		cout << num << ' ';
	}
	cout << "]\n";
}

int main(int argc, char* argv[])
{
	if (argc != 5) {
		cout << "Invalid arguments!\n" << argc;
		return 1;
	}
	ArgumentManager am(argc, argv);
	string input = am.get("input");
	string command = am.get("command");
	string output = am.get("output");

	ifstream ifile;
	ifile.open(input);
	ifstream cfile;
	cfile.open(command);
	ofstream ofile;
	ofile.open(output);

	//Get degree and initialize tree of that degree
	string line;
	string last;
	getline(cfile, line);
	if (line[line.length() - 2] == '=')
		last = line[line.length() - 1];
	else {
		int i = line.length() - 3;
		while (line[i] != '=')
			i--;
		last = line.substr(i + 1, line.length() - i);
	}
	BTree tree(stoi(last));

	//Fill tree with data
	while (getline(ifile, line)) {
		int count = 1;
		for (int j = 0; j < line.length(); j++) {
			if (line[j] == ' ')
				count++;
		}

		if (count == 1)
			tree.insert(stoi(line));
		else {
			int i = 0;
			while (i < count) {
				if (tree.search(stoi(line.substr(0, line.find(" ")))) == NULL) {
					tree.insert(stoi(line.substr(0, line.find(" "))));
				}
				line.erase(0, line.find(" ") + 1);
				i += 1;
			}
		}
	}

	//Execute commands from cfile
	while (getline(cfile, line)) {
		if (line == "Inorder Traversal")
			tree.traverse();
		else {
			if (line[line.length() - 2] == ' ')
				last = line[line.length() - 1];
			else {
				int i = line.length() - 3;
				while (line[i] != ' ')
					i--;
				last = line.substr(i + 1, line.length() - i);
			}
			//tree.traverseLevel(1/*stoi(last)*/);
		}
	}

}
